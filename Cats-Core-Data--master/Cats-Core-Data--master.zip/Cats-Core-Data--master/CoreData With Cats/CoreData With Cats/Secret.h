//
//  Secret.h
//  Cats
//
//  Created by Paul on 2017-09-25.
//  Copyright © 2017 Paul. All rights reserved.
//

#ifndef Secret_h
#define Secret_h

static NSString * FLICKR_API_KEY = @"c7049e84540c2a5084fedc19025bb099";


#endif /* Secret_h */
