//
//  DetailedViewController.h
//  Cats
//
//  Created by Paul on 2017-09-26.
//  Copyright © 2017 Paul. All rights reserved.
//

#import "ViewController.h"
#import "FlickrPhoto.h"

@interface DetailedViewController : ViewController

@property (nonatomic) FlickrPhoto *flickrPhoto;

@end
