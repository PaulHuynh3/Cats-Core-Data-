//
//  CatPhotoCollectionViewCell.h
//  Cats
//
//  Created by Paul on 2017-09-25.
//  Copyright © 2017 Paul. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FlickrPhoto.h"

@interface CatPhotoCollectionViewCell : UICollectionViewCell

@property (strong ,nonatomic)FlickrPhoto* flickrPhoto;




@end
